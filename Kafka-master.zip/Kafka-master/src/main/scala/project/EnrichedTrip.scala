package project

case class EnrichedTrip(tripRoute: TripRoute, calendar: Calendar)
