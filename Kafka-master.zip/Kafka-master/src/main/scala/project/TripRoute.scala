package project

case class TripRoute (trip: Trip, route: Route)
